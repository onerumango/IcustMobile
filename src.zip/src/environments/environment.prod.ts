export const environment = {
  production: true,


  
  // ICUST_URL: 'http://localhost:1212', // phase2 for local testing
 ICUST_URL:'http://192.168.0.14:8081/Icust-Digital-Banking'
  
 




};
